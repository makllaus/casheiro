<?php
  $servername = "localhost";
  $username = "root";
  $db_password = "root";
  $dbname = "db_controlfinance";
  $table_usuaruio = "usuario";
?>
