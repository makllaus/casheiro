<?php
  $servername = "localhost";
  $username = "root";
  $db_password = "root";
  $dbname = "login";
  $table_users = "users";
?>
