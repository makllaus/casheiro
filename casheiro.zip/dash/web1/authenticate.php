<?php
session_start();

if (isset($_SESSION["user_id"]) && isset($_SESSION["user_nome"]) && isset($_SESSION["user_email"])) {
    $login = true;
    $user_id = $_SESSION["user_id"];
    $user_name = $_SESSION["user_nome"];
    $user_email = $_SESSION["user_email"];
}
else{
    $login = false;
}

?>
