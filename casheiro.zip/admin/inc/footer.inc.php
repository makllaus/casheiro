		
		</div>

	</div>

	<div id="footer">
		&copy; <?php echo SITE_TITLE; ?>. All rights reserved.
		<!-- Do not remove this copyright notice! -->
		Powered by <a href="http://www.cashbackengine.net" target="_blank">CashbackEngine</a> v2.0
		<!-- ------------------------------------ -->
	</div>

</div>


<!-- fim div #fundo_site -->
</div>
</body>
</html>