
	$(document).ready(function() {
		$(".bt_menuHover").hide();
	});