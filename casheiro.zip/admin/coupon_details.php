<?php
/*******************************************************************\
 * CashbackEngine v2.0
 * http://www.CashbackEngine.net
 *
 * Copyright (c) 2010-2013 CashbackEngine Software. All rights reserved.
 * ------------ CashbackEngine IS NOT FREE SOFTWARE --------------
\*******************************************************************/

	session_start();
	require_once("../inc/adm_auth.inc.php");
	require_once("../inc/config.inc.php");
	require_once("./inc/admin_funcs.inc.php");


	if (isset($_GET['id']) && is_numeric($_GET['id']))
	{
		$pn			= (int)$_GET['pn'];
		$couponid	= (int)$_GET['id'];

		$query = "SELECT *, DATE_FORMAT(added, '%e %b %Y %h:%i %p') AS date_added, DATE_FORMAT(start_date, '%d %b %Y %h:%i') AS coupon_start_date, DATE_FORMAT(end_date, '%d %b %Y %h:%i') AS coupon_end_date, UNIX_TIMESTAMP(end_date) - UNIX_TIMESTAMP() AS time_left FROM cashbackengine_coupons WHERE coupon_id='$couponid' LIMIT 1";
		$result = smart_mysql_query($query);
		$total = mysql_num_rows($result);
	}


	$title = "Coupon Details";
	require_once ("inc/header.inc.php");

?>
    
     <h2>Coupon Details</h2>

	 <?php if ($total > 0) {
	
		 $row = mysql_fetch_array($result);

	 ?>
		<img src="images/icons/scissors.png" />
        <table style="border: 4px dashed #eee;" width="100%" cellpadding="2" cellspacing="5" border="0" align="center">
		<?php if ($row['exclusive'] == 1) { ?>
			<tr>
				<td colspan="2" align="right" align="right" valign="top"><img src="images/icons/featured.png" align="absmiddle" /> <span style="color:#EF8407;">Exclusive  Coupon</span></td>
			</tr>
		<?php } ?>
			</tr>
				<td width="30%" valign="middle" align="right" class="tb1">Title:</td>
				<td width="70%" valign="top"><b><?php echo $row['title']; ?></b></td>
			</tr>
			<?php if ($row['retailer_id'] > 0) { ?>
				<tr>
					<td width="30%" valign="middle" align="right" class="tb1">Store:</td>
					<td width="70%" valign="top"><a href="retailer_details.php?id=<?php echo $row['retailer_id']; ?>"><?php echo GetStoreName($row['retailer_id']); ?></a></td>
				</tr>
			<?php } ?>
			<tr>
				<td width="30%" valign="middle" align="right" class="tb1">Coupon Code:</td>
				<td width="70%" valign="top"><?php echo $row['code']; ?></td>
			</tr>
			<?php if ($row['start_date'] != "0000-00-00 00:00:00") { ?>
			<tr>
				<td width="30%" valign="middle" align="right" class="tb1">Start Date:</td>
				<td width="70%" valign="top"><?php echo $row['coupon_start_date']; ?></td>
			</tr>
			<?php } ?>
			<tr>
				<td width="30%" valign="middle" align="right" class="tb1">Expires in:</td>
				<td width="70%" valign="top"><?php if ($row['end_date'] != "0000-00-00 00:00:00") { echo GetTimeLeft($row['time_left']); }else{ echo "----"; } ?></td>
			</tr>
			<tr>
				<td width="30%" valign="middle" align="right" class="tb1">Expiry Date:</td>
				<td width="70%" valign="top"><?php echo $row['coupon_end_date']; ?></td>
			</tr>
			<?php if ($row['description'] != "") { ?>
			<tr>
				<td valign="top" align="right" class="tb1">Description:</td>
				<td valign="top"><?php echo $row['description']; ?></td>
            </tr>
			<?php } ?>
			<tr>
				<td valign="top" align="right" class="tb1">Visits:</td>
				<td valign="top"><?php echo number_format($row['visits']); ?></td>
            </tr>
			<tr>
				<td valign="top" align="right" class="tb1">Date Added:</td>
				<td valign="top"><?php echo $row['date_added']; ?></td>
            </tr>
            <tr>
				<td valign="middle" align="right" class="tb1">Status:</td>
				<td valign="top">
				<?php
						switch ($row['status'])
						{
							case "active": echo "<span class='active_s'>".$row['status']."</span>"; break;
							case "inactive": echo "<span class='inactive_s'>".$row['status']."</span>"; break;
							case "expired": echo "<span class='expired_status'>".$row['status']."</span>"; break;
							default: echo "<span class='default_status'>".$row['status']."</span>"; break;
						}
				?>
				</td>
            </tr>
            <tr>
              <td align="center" colspan="2" valign="bottom">
				<input type="button" class="submit" name="edit" value="Edit Coupon" onClick="javascript:document.location.href='coupon_edit.php?id=<?php echo $row['coupon_id']; ?>&page=<?php echo $pn; ?>&column=<?php echo $_GET['column']; ?>&order=<?php echo $_GET['order']; ?>'" /> &nbsp; 
				<input type="button" class="submit" name="cancel" value="Go Back" onClick="javascript:document.location.href='coupons.php?page=<?php echo $pn; ?>&column=<?php echo $_GET['column']; ?>&order=<?php echo $_GET['order']; ?>'" />
			  </td>
            </tr>
          </table>
      
	  <?php }else{ ?>
			<p align="center">Sorry, no coupon found.<br/><br/><a class="goback" href="#" onclick="history.go(-1);return false;">Go Back</a></p>
      <?php } ?>

<?php require_once ("inc/footer.inc.php"); ?>